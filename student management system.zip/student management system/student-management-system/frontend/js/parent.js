const token = localStorage.getItem('token');

async function fetchParentData() {
  const res = await fetch('http://localhost:5000/api/parents/me', {
    headers: { Authorization: `Bearer ${token}` }
  });
  const parent = await res.json();
  const childList = parent.children.map(c => `<li>${c.user.name} - Class ${c.class}</li>`).join('');
  document.getElementById('parentInfo').innerHTML = `
    Name: ${parent.user.name}<br>
    Children:
    <ul>${childList}</ul>
  `;
}

fetchParentData();
