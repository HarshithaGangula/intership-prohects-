const token = localStorage.getItem('token');

async function fetchTeacherData() {
  const res = await fetch('http://localhost:5000/api/teachers/me', {
    headers: { Authorization: `Bearer ${token}` }
  });
  const teacher = await res.json();
  document.getElementById('teacherInfo').innerHTML = `
    Name: ${teacher.user.name} <br> Subjects: ${teacher.subjects.join(', ')}
  `;
}

fetchTeacherData();
