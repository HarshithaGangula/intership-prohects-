const token = localStorage.getItem('token');

async function fetchStudentData() {
  const res = await fetch('http://localhost:5000/api/students/me', {
    headers: { Authorization: `Bearer ${token}` }
  });
  const student = await res.json();
  document.getElementById('studentInfo').innerHTML = `
    Name: ${student.user.name} <br> Class: ${student.class}
  `;

  const gradeRes = await fetch(`http://localhost:5000/api/grades/student/${student._id}`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  const grades = await gradeRes.json();
  const list = document.getElementById('gradeList');
  grades.forEach(g => {
    const li = document.createElement('li');
    li.textContent = `${g.subject}: ${g.score}`;
    list.appendChild(li);
  });
}

fetchStudentData();
