const express = require('express');
const router = express.Router();
const studentController = require('../controllers/studentController');
const { authenticateToken } = require('../middleware/authMiddleware');
const { authorizeRoles } = require('../middleware/roleMiddleware');

router.get('/', authenticateToken, authorizeRoles('admin', 'teacher'), studentController.getAllStudents);
router.get('/:id', authenticateToken, authorizeRoles('admin', 'teacher', 'student'), studentController.getStudentById);
router.put('/:id', authenticateToken, authorizeRoles('admin'), studentController.updateStudent);

module.exports = router;
