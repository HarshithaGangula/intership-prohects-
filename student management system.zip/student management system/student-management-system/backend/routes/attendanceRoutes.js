const express = require('express');
const router = express.Router();
const attendanceController = require('../controllers/attendanceController');
const { authenticateToken } = require('../middleware/authMiddleware');
const { authorizeRoles } = require('../middleware/roleMiddleware');

router.post('/', authenticateToken, authorizeRoles('teacher', 'admin'), attendanceController.markAttendance);
router.get('/student/:studentId', authenticateToken, authorizeRoles('student', 'teacher', 'parent', 'admin'), attendanceController.getAttendanceByStudent);
router.get('/', authenticateToken, authorizeRoles('teacher', 'admin'), attendanceController.getAttendanceByClassAndDate);

module.exports = router;
