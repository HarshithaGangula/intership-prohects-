const express = require('express');
const router = express.Router();
const parentController = require('../controllers/parentController');
const { authenticateToken } = require('../middleware/authMiddleware');
const { authorizeRoles } = require('../middleware/roleMiddleware');

router.get('/', authenticateToken, authorizeRoles('admin'), parentController.getAllParents);
router.get('/:id', authenticateToken, authorizeRoles('admin', 'parent'), parentController.getParentById);

module.exports = router;
