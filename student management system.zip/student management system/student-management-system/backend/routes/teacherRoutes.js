const express = require('express');
const router = express.Router();
const teacherController = require('../controllers/teacherController');
const { authenticateToken } = require('../middleware/authMiddleware');
const { authorizeRoles } = require('../middleware/roleMiddleware');

router.get('/', authenticateToken, authorizeRoles('admin'), teacherController.getAllTeachers);
router.get('/:id', authenticateToken, authorizeRoles('admin', 'teacher'), teacherController.getTeacherById);
router.put('/:id', authenticateToken, authorizeRoles('admin'), teacherController.updateTeacher);

module.exports = router;
