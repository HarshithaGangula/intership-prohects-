const express = require('express');
const router = express.Router();
const gradeController = require('../controllers/gradeController');
const { authenticateToken } = require('../middleware/authMiddleware');
const { authorizeRoles } = require('../middleware/roleMiddleware');

router.post('/', authenticateToken, authorizeRoles('teacher', 'admin'), gradeController.addGrade);
router.get('/student/:studentId', authenticateToken, authorizeRoles('teacher', 'student', 'parent', 'admin'), gradeController.getGradesByStudent);

module.exports = router;
