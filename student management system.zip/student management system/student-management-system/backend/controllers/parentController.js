const Parent = require('../models/Parent');

exports.getAllParents = async (req, res) => {
  try {
    const parents = await Parent.find().populate('children');
    res.json(parents);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getParentById = async (req, res) => {
  try {
    const parent = await Parent.findById(req.params.id).populate('children');
    if (!parent) return res.status(404).json({ error: 'Parent not found' });
    res.json(parent);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
