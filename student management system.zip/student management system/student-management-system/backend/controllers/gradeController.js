const Grade = require('../models/Grade');
const Student = require('../models/Student');

exports.addGrade = async (req, res) => {
  const { studentId, subject, score } = req.body;
  try {
    const grade = await Grade.create({ student: studentId, subject, score });
    await Student.findByIdAndUpdate(studentId, { $push: { grades: grade._id } });
    res.status(201).json({ message: 'Grade added', grade });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getGradesByStudent = async (req, res) => {
  try {
    const grades = await Grade.find({ student: req.params.studentId });
    res.json(grades);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
