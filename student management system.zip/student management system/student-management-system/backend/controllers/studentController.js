const Grade = require('../models/Grade');
const Attendance = require('../models/Attendance');
const Message = require('../models/Message');

exports.getGrades = async (req, res) => {
  const grades = await Grade.find({ studentId: req.user.id });
  res.json(grades);
};

exports.getAttendance = async (req, res) => {
  const attendance = await Attendance.find({ studentId: req.user.id });
  res.json(attendance);
};

exports.sendMessage = async (req, res) => {
  const message = new Message({
    senderId: req.user.id,
    receiverId: req.body.receiverId,
    content: req.body.content
  });
  await message.save();
  res.json({ message: "Message sent" });
};
