const Attendance = require('../models/Attendance');

// Add attendance
exports.markAttendance = async (req, res) => {
  const { studentId, date, status, class: className } = req.body;
  try {
    const attendance = await Attendance.create({
      student: studentId,
      date,
      status,
      class: className,
      recordedBy: req.user._id
    });
    res.status(201).json({ message: 'Attendance marked', attendance });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// Get attendance by student
exports.getAttendanceByStudent = async (req, res) => {
  try {
    const records = await Attendance.find({ student: req.params.studentId }).sort({ date: -1 });
    res.json(records);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Get attendance by class & date
exports.getAttendanceByClassAndDate = async (req, res) => {
  const { className, date } = req.query;
  try {
    const records = await Attendance.find({ class: className, date });
    res.json(records);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
